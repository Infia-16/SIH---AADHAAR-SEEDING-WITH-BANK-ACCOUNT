import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Play, Download, Globe, FileText, Video } from "lucide-react"
import { Button } from "@/components/ui/button"

const languages = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "hi", name: "हिंदी", flag: "🇮🇳" },
  { code: "te", name: "తెలుగు", flag: "🇮🇳" },
  { code: "ta", name: "தமிழ்", flag: "🇮🇳" },
]

const steps = [
  {
    id: 1,
    title: "Prepare Documents",
    description: "Gather your Aadhaar card and bank account details",
    image: "/aadhaar-card-and-bank-documents.jpg",
    tips: [
      "Keep your Aadhaar card handy",
      "Have your bank account number ready",
      "Ensure mobile number is linked to Aadhaar",
    ],
  },
  {
    id: 2,
    title: "Visit Bank or Use Online Portal",
    description: "Go to your bank branch or use their online banking portal",
    image: "/bank-branch-or-online-banking-interface.jpg",
    tips: [
      "Check if your bank supports online Aadhaar seeding",
      "Carry original documents if visiting branch",
      "Use official bank website only",
    ],
  },
  {
    id: 3,
    title: "Fill Seeding Form",
    description: "Complete the Aadhaar seeding form with accurate details",
    image: "/person-filling-bank-form.jpg",
    tips: ["Double-check Aadhaar number", "Verify bank account details", "Sign the form clearly"],
  },
  {
    id: 4,
    title: "OTP Verification",
    description: "Enter the OTP sent to your registered mobile number",
    image: "/mobile-phone-with-otp-message.jpg",
    tips: ["Check SMS for OTP", "Enter OTP within time limit", "Request new OTP if expired"],
  },
  {
    id: 5,
    title: "Confirmation",
    description: "Receive confirmation of successful Aadhaar seeding",
    image: "/success-confirmation-message.jpg",
    tips: ["Save confirmation receipt", "Note down reference number", "Keep for future reference"],
  },
]

export default function GuidePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="lg:ml-64 p-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground font-playfair mb-2">Aadhaar Seeding Guide</h1>
            <p className="text-muted-foreground">Complete guide with video tutorials and step-by-step instructions</p>
          </div>

          {/* Language Selection */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Choose Your Language
              </CardTitle>
              <CardDescription>Select your preferred language for instructions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                {languages.map((lang) => (
                  <Button key={lang.code} variant="outline" className="gap-2 bg-transparent">
                    <span>{lang.flag}</span>
                    {lang.name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="video" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="video" className="gap-2">
                <Video className="h-4 w-4" />
                Video Guide
              </TabsTrigger>
              <TabsTrigger value="steps" className="gap-2">
                <FileText className="h-4 w-4" />
                Step-by-Step
              </TabsTrigger>
              <TabsTrigger value="resources" className="gap-2">
                <Download className="h-4 w-4" />
                Resources
              </TabsTrigger>
            </TabsList>

            {/* Video Guide Tab */}
            <TabsContent value="video" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Video Tutorial</CardTitle>
                  <CardDescription>Watch the complete Aadhaar seeding process</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-4">
                    <div className="text-center">
                      <Play className="h-16 w-16 text-primary mx-auto mb-4" />
                      <p className="text-muted-foreground">Aadhaar Seeding Tutorial</p>
                      <p className="text-sm text-muted-foreground">Duration: 8:45</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="secondary">Beginner Friendly</Badge>
                    <Badge variant="secondary">Hindi Subtitles</Badge>
                    <Badge variant="secondary">HD Quality</Badge>
                  </div>
                  <Button className="w-full gap-2">
                    <Play className="h-4 w-4" />
                    Play Video Tutorial
                  </Button>
                </CardContent>
              </Card>

              {/* Additional Videos */}
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardContent className="p-4">
                    <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-3">
                      <Play className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-2">Online Banking Method</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      Learn how to seed Aadhaar through online banking
                    </p>
                    <Button variant="outline" size="sm" className="w-full bg-transparent">
                      Watch (5:20)
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-3">
                      <Play className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-2">Branch Visit Method</h3>
                    <p className="text-sm text-muted-foreground mb-3">Step-by-step guide for bank branch visits</p>
                    <Button variant="outline" size="sm" className="w-full bg-transparent">
                      Watch (6:15)
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Step-by-Step Tab */}
            <TabsContent value="steps" className="space-y-6">
              <div className="space-y-6">
                {steps.map((step, index) => (
                  <Card key={step.id}>
                    <CardContent className="p-6">
                      <div className="grid md:grid-cols-3 gap-6">
                        <div className="md:col-span-1">
                          <img
                            src={step.image || "/placeholder.svg"}
                            alt={step.title}
                            className="w-full h-48 object-cover rounded-lg"
                          />
                        </div>
                        <div className="md:col-span-2">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-bold">
                              {step.id}
                            </div>
                            <h3 className="text-xl font-semibold">{step.title}</h3>
                          </div>

                          <p className="text-muted-foreground mb-4">{step.description}</p>

                          <div className="space-y-2">
                            <h4 className="font-medium text-sm">Important Tips:</h4>
                            <ul className="space-y-1">
                              {step.tips.map((tip, tipIndex) => (
                                <li key={tipIndex} className="text-sm text-muted-foreground flex items-start gap-2">
                                  <span className="text-primary mt-1">•</span>
                                  {tip}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Resources Tab */}
            <TabsContent value="resources" className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Download Guides</CardTitle>
                    <CardDescription>Printable guides and forms</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                      <Download className="h-4 w-4" />
                      Aadhaar Seeding Form (PDF)
                    </Button>
                    <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                      <Download className="h-4 w-4" />
                      Step-by-Step Guide (PDF)
                    </Button>
                    <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                      <Download className="h-4 w-4" />
                      Troubleshooting Guide (PDF)
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Multilingual Resources</CardTitle>
                    <CardDescription>Guides in different languages</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {languages.map((lang) => (
                      <Button key={lang.code} variant="outline" className="w-full justify-start gap-2 bg-transparent">
                        <span>{lang.flag}</span>
                        Guide in {lang.name}
                      </Button>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Quick Reference</CardTitle>
                    <CardDescription>Important information at a glance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Required Documents:</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li>• Aadhaar Card (original)</li>
                          <li>• Bank Account Details</li>
                          <li>• Mobile Number (linked to Aadhaar)</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Processing Time:</h4>
                        <p className="text-sm text-muted-foreground">Usually 2-3 working days</p>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Support:</h4>
                        <p className="text-sm text-muted-foreground">Contact your bank's customer service</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Frequently Asked Questions</CardTitle>
                    <CardDescription>Common questions and answers</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <h4 className="font-medium text-sm mb-1">What if I don't receive OTP?</h4>
                        <p className="text-sm text-muted-foreground">
                          Check if your mobile number is linked to Aadhaar and try again.
                        </p>
                      </div>
                      <div>
                        <h4 className="font-medium text-sm mb-1">Can I seed multiple accounts?</h4>
                        <p className="text-sm text-muted-foreground">
                          Yes, you can seed Aadhaar with multiple bank accounts.
                        </p>
                      </div>
                      <div>
                        <h4 className="font-medium text-sm mb-1">Is there any fee?</h4>
                        <p className="text-sm text-muted-foreground">
                          No, Aadhaar seeding is completely free of charge.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
