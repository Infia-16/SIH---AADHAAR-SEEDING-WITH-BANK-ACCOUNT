"use client"

import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Award, Download, Share2, CheckCircle, Calendar, User, CreditCard, QrCode, Star } from "lucide-react"
import { useState } from "react"

export default function BadgePage() {
  const [isDownloading, setIsDownloading] = useState(false)
  const [isSharing, setIsSharing] = useState(false)

  // Mock user data - in real app this would come from authentication/database
  const userData = {
    name: "Rajesh Kumar",
    studentId: "STU2024001",
    aadhaarNumber: "1234 5678 9012",
    bankAccount: "****7890",
    completionDate: "2024-01-15",
    referenceNumber: "ADS2024001234",
  }

  const handleDownload = async () => {
    setIsDownloading(true)
    // Simulate download process
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsDownloading(false)
    // In real app, this would trigger actual download
    console.log("Downloading certificate...")
  }

  const handleShare = async () => {
    setIsSharing(true)
    // Simulate sharing process
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsSharing(false)
    // In real app, this would open share dialog
    console.log("Sharing certificate...")
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="lg:ml-64 p-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold text-foreground font-playfair mb-2">Digital Certificate</h1>
            <p className="text-muted-foreground">Your Aadhaar seeding completion certificate</p>
          </div>

          {/* Main Certificate Card */}
          <Card className="mb-8 relative overflow-hidden">
            {/* Decorative background pattern */}
            <div className="absolute inset-0 opacity-5">
              <div className="absolute top-0 left-0 w-32 h-32 bg-primary rounded-full -translate-x-16 -translate-y-16"></div>
              <div className="absolute bottom-0 right-0 w-40 h-40 bg-secondary rounded-full translate-x-20 translate-y-20"></div>
              <div className="absolute top-1/2 left-1/2 w-24 h-24 bg-accent rounded-full -translate-x-12 -translate-y-12"></div>
            </div>

            <CardContent className="p-8 relative z-10">
              {/* Certificate Header */}
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-primary/10 rounded-full mb-4">
                  <Award className="h-10 w-10 text-primary" />
                </div>
                <h2 className="text-2xl font-bold text-foreground font-playfair mb-2">Certificate of Completion</h2>
                <p className="text-muted-foreground">Aadhaar Seeding Process</p>
              </div>

              {/* Congratulations Message */}
              <div className="text-center mb-8 p-6 bg-primary/5 rounded-lg border border-primary/20">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <CheckCircle className="h-6 w-6 text-primary" />
                  <span className="text-lg font-semibold text-primary">Congratulations!</span>
                </div>
                <p className="text-foreground font-medium mb-2">Aadhaar seeding successful.</p>
                <p className="text-muted-foreground text-sm">
                  Your Aadhaar has been successfully linked with your bank account for seamless benefit transfers.
                </p>
              </div>

              {/* Certificate Details */}
              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <User className="h-5 w-5 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Student Name</p>
                      <p className="font-semibold">{userData.name}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <CreditCard className="h-5 w-5 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Student ID</p>
                      <p className="font-semibold">{userData.studentId}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Calendar className="h-5 w-5 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Completion Date</p>
                      <p className="font-semibold">{new Date(userData.completionDate).toLocaleDateString()}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Aadhaar Number</p>
                    <p className="font-semibold">{userData.aadhaarNumber}</p>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Bank Account</p>
                    <p className="font-semibold">{userData.bankAccount}</p>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Reference Number</p>
                    <p className="font-semibold text-primary">{userData.referenceNumber}</p>
                  </div>
                </div>
              </div>

              {/* QR Code Section */}
              <div className="flex justify-center mb-8">
                <div className="text-center">
                  <div className="w-24 h-24 bg-muted rounded-lg flex items-center justify-center mb-2">
                    <QrCode className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <p className="text-xs text-muted-foreground">Verification QR Code</p>
                </div>
              </div>

              {/* Status Badges */}
              <div className="flex flex-wrap justify-center gap-2 mb-8">
                <Badge variant="secondary" className="gap-1">
                  <CheckCircle className="h-3 w-3" />
                  Verified
                </Badge>
                <Badge variant="secondary" className="gap-1">
                  <Star className="h-3 w-3" />
                  Authentic
                </Badge>
                <Badge variant="secondary" className="gap-1">
                  <Award className="h-3 w-3" />
                  Certified
                </Badge>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button onClick={handleDownload} disabled={isDownloading} className="gap-2">
                  <Download className="h-4 w-4" />
                  {isDownloading ? "Downloading..." : "Download Certificate"}
                </Button>
                <Button variant="outline" onClick={handleShare} disabled={isSharing} className="gap-2 bg-transparent">
                  <Share2 className="h-4 w-4" />
                  {isSharing ? "Sharing..." : "Share Certificate"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Additional Information */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">What's Next?</CardTitle>
                <CardDescription>Benefits of successful Aadhaar seeding</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>Direct benefit transfers to your account</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>Scholarship payments without delays</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>Government subsidy transfers</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>Reduced paperwork for future transactions</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Important Notes</CardTitle>
                <CardDescription>Keep these points in mind</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                    <span>Keep this certificate safe for your records</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                    <span>Reference number can be used for future queries</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                    <span>Contact your bank if you face any issues</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                    <span>This certificate is digitally signed and verified</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Footer */}
          <div className="mt-8 text-center">
            <p className="text-xs text-muted-foreground">
              This is an official digital certificate issued by the Sankalp Visualizer system.
              <br />
              Generated on {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
