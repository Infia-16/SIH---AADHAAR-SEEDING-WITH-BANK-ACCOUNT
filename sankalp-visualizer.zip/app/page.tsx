import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, Circle, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const steps = [
  {
    id: 1,
    title: "Link Aadhaar",
    description: "Connect your Aadhaar number with your bank account",
    completed: true,
  },
  {
    id: 2,
    title: "Verify OTP",
    description: "Enter the OTP sent to your registered mobile number",
    completed: true,
  },
  {
    id: 3,
    title: "Bank Confirmation",
    description: "Wait for bank confirmation of successful seeding",
    completed: false,
  },
  {
    id: 4,
    title: "Complete Process",
    description: "Receive confirmation and digital certificate",
    completed: false,
  },
]

export default function VisualizerPage() {
  const completedSteps = steps.filter((step) => step.completed).length
  const progressPercentage = (completedSteps / steps.length) * 100

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="lg:ml-64 p-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground font-playfair mb-2">Aadhaar Seeding Visualizer</h1>
            <p className="text-muted-foreground">Track your Aadhaar seeding progress step by step</p>
          </div>

          {/* Progress Overview */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Overall Progress
                <span className="text-sm font-normal text-muted-foreground">
                  {completedSteps} of {steps.length} completed
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Progress value={progressPercentage} className="mb-2" />
              <p className="text-sm text-muted-foreground">{progressPercentage}% complete</p>
            </CardContent>
          </Card>

          {/* Steps */}
          <div className="space-y-4">
            {steps.map((step, index) => (
              <Card key={step.id} className={step.completed ? "border-primary/50 bg-primary/5" : ""}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 mt-1">
                      {step.completed ? (
                        <CheckCircle className="h-6 w-6 text-primary" />
                      ) : (
                        <Circle className="h-6 w-6 text-muted-foreground" />
                      )}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-sm font-medium text-muted-foreground">Step {step.id}</span>
                        {step.completed && (
                          <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">Completed</span>
                        )}
                      </div>

                      <h3 className="text-lg font-semibold text-foreground mb-1">{step.title}</h3>

                      <p className="text-muted-foreground mb-4">{step.description}</p>

                      {!step.completed && index === completedSteps && (
                        <Button className="gap-2">
                          Continue to Next Step
                          <ArrowRight className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Help Section */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Need Help?</CardTitle>
              <CardDescription>Get assistance with the Aadhaar seeding process</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button variant="outline" className="flex-1 bg-transparent">
                  View Guide
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent">
                  Contact Support
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
