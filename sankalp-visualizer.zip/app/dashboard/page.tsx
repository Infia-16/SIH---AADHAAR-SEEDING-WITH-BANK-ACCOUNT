"use client"

import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { Users, CheckCircle, Clock, TrendingUp, Download, Search, AlertCircle, UserCheck, UserX } from "lucide-react"
import { useState } from "react"

// Mock data for the dashboard
const mockStudents = [
  {
    id: 1,
    name: "Rajesh Kumar",
    studentId: "STU2024001",
    aadhaar: "1234 5678 9012",
    status: "completed",
    completedDate: "2024-01-15",
    class: "12th A",
    bank: "SBI",
  },
  {
    id: 2,
    name: "Priya Sharma",
    studentId: "STU2024002",
    aadhaar: "2345 6789 0123",
    status: "completed",
    completedDate: "2024-01-16",
    class: "12th B",
    bank: "HDFC",
  },
  {
    id: 3,
    name: "Amit Patel",
    studentId: "STU2024003",
    aadhaar: "3456 7890 1234",
    status: "completed",
    completedDate: "2024-01-17",
    class: "11th A",
    bank: "ICICI",
  },
  {
    id: 4,
    name: "Sneha Reddy",
    studentId: "STU2024004",
    aadhaar: "4567 8901 2345",
    status: "pending",
    completedDate: null,
    class: "12th A",
    bank: "Axis",
  },
  {
    id: 5,
    name: "Vikram Singh",
    studentId: "STU2024005",
    aadhaar: "5678 9012 3456",
    status: "completed",
    completedDate: "2024-01-19",
    class: "11th B",
    bank: "PNB",
  },
  {
    id: 6,
    name: "Anita Gupta",
    studentId: "STU2024006",
    aadhaar: "6789 0123 4567",
    status: "pending",
    completedDate: null,
    class: "12th B",
    bank: "SBI",
  },
  {
    id: 7,
    name: "Rohit Verma",
    studentId: "STU2024007",
    aadhaar: "7890 1234 5678",
    status: "completed",
    completedDate: "2024-01-21",
    class: "11th A",
    bank: "HDFC",
  },
  {
    id: 8,
    name: "Kavya Nair",
    studentId: "STU2024008",
    aadhaar: "8901 2345 6789",
    status: "pending",
    completedDate: null,
    class: "12th A",
    bank: "ICICI",
  },
]

const chartData = [
  { name: "Jan Week 1", completed: 2, pending: 8 },
  { name: "Jan Week 2", completed: 4, pending: 6 },
  { name: "Jan Week 3", completed: 6, pending: 4 },
  { name: "Jan Week 4", completed: 5, pending: 3 },
]

const pieData = [
  { name: "Completed", value: 5, color: "hsl(var(--primary))" },
  { name: "Pending", value: 3, color: "hsl(var(--muted))" },
]

const bankData = [
  { name: "SBI", count: 2 },
  { name: "HDFC", count: 2 },
  { name: "ICICI", count: 2 },
  { name: "Axis", count: 1 },
  { name: "PNB", count: 1 },
]

export default function DashboardPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [classFilter, setClassFilter] = useState("all")

  const completedStudents = mockStudents.filter((s) => s.status === "completed")
  const pendingStudents = mockStudents.filter((s) => s.status === "pending")

  const filteredStudents = mockStudents.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.studentId.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || student.status === statusFilter
    const matchesClass = classFilter === "all" || student.class === classFilter

    return matchesSearch && matchesStatus && matchesClass
  })

  const completionRate = (completedStudents.length / mockStudents.length) * 100

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="lg:ml-64 p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground font-playfair mb-2">Teacher Dashboard</h1>
            <p className="text-muted-foreground">Monitor and manage student Aadhaar seeding progress</p>
          </div>

          {/* Stats Overview */}
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{mockStudents.length}</p>
                    <p className="text-sm text-muted-foreground">Total Students</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-primary">{completedStudents.length}</p>
                    <p className="text-sm text-muted-foreground">Completed</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-100 rounded-lg">
                    <Clock className="h-5 w-5 text-orange-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-orange-600">{pendingStudents.length}</p>
                    <p className="text-sm text-muted-foreground">Pending</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <TrendingUp className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{Math.round(completionRate)}%</p>
                    <p className="text-sm text-muted-foreground">Completion Rate</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts Section */}
          <div className="grid lg:grid-cols-2 gap-6 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Progress Over Time</CardTitle>
                <CardDescription>Weekly completion trends</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="completed" fill="hsl(var(--primary))" name="Completed" />
                    <Bar dataKey="pending" fill="hsl(var(--muted))" name="Pending" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Completion Status</CardTitle>
                <CardDescription>Overall progress distribution</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex justify-center gap-4 mt-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-primary rounded-full"></div>
                    <span className="text-sm">Completed ({completedStudents.length})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-muted rounded-full"></div>
                    <span className="text-sm">Pending ({pendingStudents.length})</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Bank Distribution */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Bank Distribution</CardTitle>
              <CardDescription>Students by bank preference</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={bankData} layout="horizontal">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" width={60} />
                  <Tooltip />
                  <Bar dataKey="count" fill="hsl(var(--primary))" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Student Management */}
          <Tabs defaultValue="all" className="space-y-6">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="all">All Students</TabsTrigger>
                <TabsTrigger value="completed" className="gap-2">
                  <UserCheck className="h-4 w-4" />
                  Completed
                </TabsTrigger>
                <TabsTrigger value="pending" className="gap-2">
                  <UserX className="h-4 w-4" />
                  Pending
                </TabsTrigger>
              </TabsList>

              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Download className="h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>

            {/* Filters */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search by name or student ID..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={classFilter} onValueChange={setClassFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <SelectValue placeholder="Class" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Classes</SelectItem>
                      <SelectItem value="11th A">11th A</SelectItem>
                      <SelectItem value="11th B">11th B</SelectItem>
                      <SelectItem value="12th A">12th A</SelectItem>
                      <SelectItem value="12th B">12th B</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <TabsContent value="all">
              <Card>
                <CardHeader>
                  <CardTitle>All Students ({filteredStudents.length})</CardTitle>
                  <CardDescription>Complete list of students and their seeding status</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Student</TableHead>
                        <TableHead>Class</TableHead>
                        <TableHead>Aadhaar</TableHead>
                        <TableHead>Bank</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Completed Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredStudents.map((student) => (
                        <TableRow key={student.id}>
                          <TableCell>
                            <div>
                              <p className="font-medium">{student.name}</p>
                              <p className="text-sm text-muted-foreground">{student.studentId}</p>
                            </div>
                          </TableCell>
                          <TableCell>{student.class}</TableCell>
                          <TableCell className="font-mono text-sm">{student.aadhaar}</TableCell>
                          <TableCell>{student.bank}</TableCell>
                          <TableCell>
                            <Badge variant={student.status === "completed" ? "default" : "secondary"}>
                              {student.status === "completed" ? (
                                <>
                                  <CheckCircle className="h-3 w-3 mr-1" />
                                  Completed
                                </>
                              ) : (
                                <>
                                  <Clock className="h-3 w-3 mr-1" />
                                  Pending
                                </>
                              )}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {student.completedDate ? new Date(student.completedDate).toLocaleDateString() : "-"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="completed">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-primary" />
                    Completed Students ({completedStudents.length})
                  </CardTitle>
                  <CardDescription>Students who have successfully completed Aadhaar seeding</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Student</TableHead>
                        <TableHead>Class</TableHead>
                        <TableHead>Bank</TableHead>
                        <TableHead>Completed Date</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {completedStudents.map((student) => (
                        <TableRow key={student.id}>
                          <TableCell>
                            <div>
                              <p className="font-medium">{student.name}</p>
                              <p className="text-sm text-muted-foreground">{student.studentId}</p>
                            </div>
                          </TableCell>
                          <TableCell>{student.class}</TableCell>
                          <TableCell>{student.bank}</TableCell>
                          <TableCell>{new Date(student.completedDate!).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <Button variant="outline" size="sm" className="bg-transparent">
                              View Certificate
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="pending">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-orange-600" />
                    Pending Students ({pendingStudents.length})
                  </CardTitle>
                  <CardDescription>Students who still need to complete their Aadhaar seeding</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Student</TableHead>
                        <TableHead>Class</TableHead>
                        <TableHead>Bank</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pendingStudents.map((student) => (
                        <TableRow key={student.id}>
                          <TableCell>
                            <div>
                              <p className="font-medium">{student.name}</p>
                              <p className="text-sm text-muted-foreground">{student.studentId}</p>
                            </div>
                          </TableCell>
                          <TableCell>{student.class}</TableCell>
                          <TableCell>{student.bank}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" className="bg-transparent">
                                Send Reminder
                              </Button>
                              <Button size="sm">Help Complete</Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
