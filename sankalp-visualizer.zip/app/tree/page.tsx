"use client"

import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { TreePine, Users, Target, TrendingUp, Leaf, Award, Star } from "lucide-react"
import { useState, useEffect } from "react"

// Mock data for students - in real app this would come from database
const mockStudents = [
  { id: 1, name: "Rajesh Kumar", completed: true, date: "2024-01-15" },
  { id: 2, name: "Priya Sharma", completed: true, date: "2024-01-16" },
  { id: 3, name: "Amit Patel", completed: true, date: "2024-01-17" },
  { id: 4, name: "Sneha Reddy", completed: true, date: "2024-01-18" },
  { id: 5, name: "Vikram Singh", completed: true, date: "2024-01-19" },
  { id: 6, name: "Anita Gupta", completed: true, date: "2024-01-20" },
  { id: 7, name: "Rohit Verma", completed: true, date: "2024-01-21" },
  { id: 8, name: "Kavya Nair", completed: true, date: "2024-01-22" },
  { id: 9, name: "Arjun Mehta", completed: false, date: null },
  { id: 10, name: "Deepika Joshi", completed: false, date: null },
]

const TreeLeaf = ({ student, index, isVisible }: { student: any; index: number; isVisible: boolean }) => {
  const positions = [
    // Tree structure positions (x, y percentages)
    { x: 50, y: 85 }, // Root/trunk area
    { x: 45, y: 75 },
    { x: 55, y: 75 },
    { x: 40, y: 65 },
    { x: 50, y: 65 },
    { x: 60, y: 65 },
    { x: 35, y: 55 },
    { x: 45, y: 55 },
    { x: 55, y: 55 },
    { x: 65, y: 55 },
  ]

  const position = positions[index] || { x: 50, y: 50 }

  return (
    <div
      className={`absolute transition-all duration-1000 transform ${
        isVisible && student.completed ? "scale-100 opacity-100" : "scale-0 opacity-0"
      }`}
      style={{
        left: `${position.x}%`,
        top: `${position.y}%`,
        transform: `translate(-50%, -50%) ${isVisible && student.completed ? "scale(1)" : "scale(0)"}`,
      }}
    >
      <div className="relative group cursor-pointer">
        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow">
          <Leaf className="h-4 w-4 text-primary-foreground" />
        </div>
        {/* Tooltip */}
        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-foreground text-background text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
          {student.name}
          {student.date && (
            <>
              <br />
              <span className="text-xs opacity-75">{new Date(student.date).toLocaleDateString()}</span>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default function TreePage() {
  const [animationStep, setAnimationStep] = useState(0)
  const [showCelebration, setShowCelebration] = useState(false)

  const completedStudents = mockStudents.filter((s) => s.completed)
  const totalStudents = mockStudents.length
  const completionRate = (completedStudents.length / totalStudents) * 100

  useEffect(() => {
    // Animate leaves appearing one by one
    const timer = setInterval(() => {
      setAnimationStep((prev) => {
        if (prev < completedStudents.length) {
          return prev + 1
        }
        clearInterval(timer)
        return prev
      })
    }, 500)

    return () => clearInterval(timer)
  }, [completedStudents.length])

  useEffect(() => {
    // Show celebration when tree is complete
    if (animationStep === completedStudents.length && completedStudents.length > 5) {
      setShowCelebration(true)
      const timer = setTimeout(() => setShowCelebration(false), 3000)
      return () => clearTimeout(timer)
    }
  }, [animationStep, completedStudents.length])

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="lg:ml-64 p-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground font-playfair mb-2">Sankalp Tree</h1>
            <p className="text-muted-foreground">
              Watch our community grow as each student completes their Aadhaar seeding
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{completedStudents.length}</p>
                    <p className="text-sm text-muted-foreground">Completed</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-secondary/10 rounded-lg">
                    <Target className="h-5 w-5 text-secondary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{totalStudents}</p>
                    <p className="text-sm text-muted-foreground">Total Students</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-accent/10 rounded-lg">
                    <TrendingUp className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{Math.round(completionRate)}%</p>
                    <p className="text-sm text-muted-foreground">Completion Rate</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <TreePine className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{animationStep}</p>
                    <p className="text-sm text-muted-foreground">Leaves Grown</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Progress Bar */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Community Progress</span>
                <Badge variant="secondary">{Math.round(completionRate)}% Complete</Badge>
              </CardTitle>
              <CardDescription>Track our collective journey towards 100% Aadhaar seeding</CardDescription>
            </CardHeader>
            <CardContent>
              <Progress value={completionRate} className="mb-2" />
              <p className="text-sm text-muted-foreground">
                {completedStudents.length} out of {totalStudents} students have completed their seeding
              </p>
            </CardContent>
          </Card>

          {/* Main Tree Visualization */}
          <Card className="mb-8 relative overflow-hidden">
            <CardContent className="p-8">
              {/* Celebration Animation */}
              {showCelebration && (
                <div className="absolute inset-0 flex items-center justify-center z-20 bg-background/80">
                  <div className="text-center animate-bounce">
                    <Star className="h-16 w-16 text-primary mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-primary mb-2">Congratulations!</h3>
                    <p className="text-muted-foreground">Our Sankalp Tree is flourishing!</p>
                  </div>
                </div>
              )}

              <div className="text-center mb-8">
                <h3 className="text-xl font-semibold mb-2">The Sankalp Tree</h3>
                <p className="text-muted-foreground">
                  Each leaf represents a student who has successfully completed Aadhaar seeding
                </p>
              </div>

              {/* Tree Container */}
              <div className="relative mx-auto" style={{ height: "400px", maxWidth: "600px" }}>
                {/* Tree Trunk and Branches SVG */}
                <svg
                  className="absolute inset-0 w-full h-full"
                  viewBox="0 0 100 100"
                  preserveAspectRatio="xMidYMid meet"
                >
                  {/* Trunk */}
                  <rect x="48" y="80" width="4" height="20" fill="currentColor" className="text-muted-foreground" />

                  {/* Main branches */}
                  <path
                    d="M50 80 L45 70"
                    stroke="currentColor"
                    strokeWidth="2"
                    className="text-muted-foreground"
                    fill="none"
                  />
                  <path
                    d="M50 80 L55 70"
                    stroke="currentColor"
                    strokeWidth="2"
                    className="text-muted-foreground"
                    fill="none"
                  />
                  <path
                    d="M50 75 L40 65"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    className="text-muted-foreground"
                    fill="none"
                  />
                  <path
                    d="M50 75 L60 65"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    className="text-muted-foreground"
                    fill="none"
                  />

                  {/* Secondary branches */}
                  <path
                    d="M45 70 L35 60"
                    stroke="currentColor"
                    strokeWidth="1"
                    className="text-muted-foreground"
                    fill="none"
                  />
                  <path
                    d="M55 70 L65 60"
                    stroke="currentColor"
                    strokeWidth="1"
                    className="text-muted-foreground"
                    fill="none"
                  />
                  <path
                    d="M40 65 L35 55"
                    stroke="currentColor"
                    strokeWidth="1"
                    className="text-muted-foreground"
                    fill="none"
                  />
                  <path
                    d="M60 65 L65 55"
                    stroke="currentColor"
                    strokeWidth="1"
                    className="text-muted-foreground"
                    fill="none"
                  />
                </svg>

                {/* Leaves */}
                {mockStudents.map((student, index) => (
                  <TreeLeaf key={student.id} student={student} index={index} isVisible={index < animationStep} />
                ))}
              </div>

              {/* Tree Legend */}
              <div className="flex justify-center gap-6 mt-8 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-primary rounded-full flex items-center justify-center">
                    <Leaf className="h-2 w-2 text-primary-foreground" />
                  </div>
                  <span>Completed Seeding</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-muted rounded-full border-2 border-muted-foreground"></div>
                  <span>Pending</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Completions */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Recent Completions
                </CardTitle>
                <CardDescription>Latest students to complete their seeding</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {completedStudents
                    .slice(-5)
                    .reverse()
                    .map((student) => (
                      <div key={student.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                            <Leaf className="h-4 w-4 text-primary-foreground" />
                          </div>
                          <span className="font-medium">{student.name}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">
                          {student.date && new Date(student.date).toLocaleDateString()}
                        </span>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Milestones</CardTitle>
                <CardDescription>Celebrate our achievements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div
                    className={`flex items-center gap-3 p-3 rounded-lg ${completedStudents.length >= 5 ? "bg-primary/10" : "bg-muted/50"}`}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${completedStudents.length >= 5 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
                    >
                      <Star className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-medium">First 5 Students</p>
                      <p className="text-sm text-muted-foreground">Build the foundation</p>
                    </div>
                    {completedStudents.length >= 5 && <Badge variant="secondary">Achieved!</Badge>}
                  </div>

                  <div
                    className={`flex items-center gap-3 p-3 rounded-lg ${completedStudents.length >= 8 ? "bg-primary/10" : "bg-muted/50"}`}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${completedStudents.length >= 8 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
                    >
                      <TreePine className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-medium">Growing Strong</p>
                      <p className="text-sm text-muted-foreground">80% completion rate</p>
                    </div>
                    {completedStudents.length >= 8 && <Badge variant="secondary">Achieved!</Badge>}
                  </div>

                  <div
                    className={`flex items-center gap-3 p-3 rounded-lg ${completedStudents.length >= 10 ? "bg-primary/10" : "bg-muted/50"}`}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${completedStudents.length >= 10 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
                    >
                      <Award className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-medium">Full Bloom</p>
                      <p className="text-sm text-muted-foreground">100% completion</p>
                    </div>
                    {completedStudents.length >= 10 && <Badge variant="secondary">Achieved!</Badge>}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Call to Action */}
          {completedStudents.length < totalStudents && (
            <Card className="mt-8 text-center">
              <CardContent className="p-8">
                <TreePine className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Help Our Tree Grow!</h3>
                <p className="text-muted-foreground mb-6">
                  We still have {totalStudents - completedStudents.length} students who need to complete their Aadhaar
                  seeding. Every completion helps our community tree flourish!
                </p>
                <Button>Encourage More Students</Button>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}
