"use client"

import React from "react"

import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { useState } from "react"
import { CheckCircle, AlertCircle, Shield, User, CreditCard, GraduationCap, ArrowRight, ArrowLeft } from "lucide-react"

interface FormData {
  aadhaarNumber: string
  bankAccount: string
  ifscCode: string
  studentId: string
  fullName: string
  mobileNumber: string
  bankName: string
  accountType: string
  consent: boolean
}

const initialFormData: FormData = {
  aadhaarNumber: "",
  bankAccount: "",
  ifscCode: "",
  studentId: "",
  fullName: "",
  mobileNumber: "",
  bankName: "",
  accountType: "",
  consent: false,
}

const steps = [
  { id: 1, title: "Personal Details", icon: User },
  { id: 2, title: "Bank Information", icon: CreditCard },
  { id: 3, title: "Student Details", icon: GraduationCap },
  { id: 4, title: "Review & Submit", icon: CheckCircle },
]

export default function FormPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState<FormData>(initialFormData)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitResult, setSubmitResult] = useState<"success" | "error" | null>(null)
  const [errors, setErrors] = useState<Partial<FormData>>({})

  const updateFormData = (field: keyof FormData, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }))
    }
  }

  const validateStep = (step: number): boolean => {
    const newErrors: Partial<FormData> = {}

    switch (step) {
      case 1:
        if (!formData.fullName.trim()) newErrors.fullName = "Full name is required"
        if (!formData.aadhaarNumber.trim()) newErrors.aadhaarNumber = "Aadhaar number is required"
        else if (!/^\d{12}$/.test(formData.aadhaarNumber.replace(/\s/g, "")))
          newErrors.aadhaarNumber = "Aadhaar number must be 12 digits"
        if (!formData.mobileNumber.trim()) newErrors.mobileNumber = "Mobile number is required"
        else if (!/^\d{10}$/.test(formData.mobileNumber)) newErrors.mobileNumber = "Mobile number must be 10 digits"
        break

      case 2:
        if (!formData.bankName.trim()) newErrors.bankName = "Bank name is required"
        if (!formData.bankAccount.trim()) newErrors.bankAccount = "Bank account number is required"
        else if (!/^\d{9,18}$/.test(formData.bankAccount)) newErrors.bankAccount = "Invalid bank account number"
        if (!formData.ifscCode.trim()) newErrors.ifscCode = "IFSC code is required"
        else if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(formData.ifscCode.toUpperCase()))
          newErrors.ifscCode = "Invalid IFSC code format"
        if (!formData.accountType) newErrors.accountType = "Account type is required"
        break

      case 3:
        if (!formData.studentId.trim()) newErrors.studentId = "Student ID is required"
        break

      case 4:
        if (!formData.consent) newErrors.consent = "You must agree to the terms and conditions"
        break
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep((prev) => Math.min(prev + 1, 4))
    }
  }

  const prevStep = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1))
  }

  const handleSubmit = async () => {
    if (!validateStep(4)) return

    setIsSubmitting(true)
    setSubmitResult(null)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Simulate random success/failure for demo
    const success = Math.random() > 0.3
    setSubmitResult(success ? "success" : "error")
    setIsSubmitting(false)
  }

  const formatAadhaar = (value: string) => {
    const digits = value.replace(/\D/g, "")
    return digits.replace(/(\d{4})(?=\d)/g, "$1 ").trim()
  }

  const progressPercentage = (currentStep / steps.length) * 100

  if (submitResult) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="lg:ml-64 p-6">
          <div className="max-w-2xl mx-auto">
            <Card className="text-center">
              <CardContent className="p-8">
                {submitResult === "success" ? (
                  <>
                    <CheckCircle className="h-16 w-16 text-primary mx-auto mb-4" />
                    <h2 className="text-2xl font-bold text-foreground mb-2">Seeding Successful!</h2>
                    <p className="text-muted-foreground mb-6">
                      Your Aadhaar has been successfully seeded with your bank account. You will receive a confirmation
                      SMS shortly.
                    </p>
                    <div className="bg-muted p-4 rounded-lg mb-6">
                      <p className="text-sm font-medium">
                        Reference Number: ADS2024{Math.floor(Math.random() * 100000)}
                      </p>
                      <p className="text-sm text-muted-foreground">Please save this for your records</p>
                    </div>
                    <div className="flex gap-4 justify-center">
                      <Button onClick={() => (window.location.href = "/badge")}>View Digital Badge</Button>
                      <Button variant="outline" onClick={() => window.location.reload()} className="bg-transparent">
                        Submit Another Form
                      </Button>
                    </div>
                  </>
                ) : (
                  <>
                    <AlertCircle className="h-16 w-16 text-destructive mx-auto mb-4" />
                    <h2 className="text-2xl font-bold text-foreground mb-2">Seeding Failed</h2>
                    <p className="text-muted-foreground mb-6">
                      There was an issue processing your request. Please check your details and try again.
                    </p>
                    <div className="flex gap-4 justify-center">
                      <Button onClick={() => setSubmitResult(null)}>Try Again</Button>
                      <Button variant="outline" className="bg-transparent">
                        Contact Support
                      </Button>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="lg:ml-64 p-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground font-playfair mb-2">Aadhaar Seeding Form</h1>
            <p className="text-muted-foreground">Complete the form to seed your Aadhaar with your bank account</p>
          </div>

          {/* Progress */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Progress</h3>
                <span className="text-sm text-muted-foreground">
                  Step {currentStep} of {steps.length}
                </span>
              </div>
              <Progress value={progressPercentage} className="mb-4" />
              <div className="flex justify-between">
                {steps.map((step) => {
                  const Icon = step.icon
                  const isActive = currentStep === step.id
                  const isCompleted = currentStep > step.id

                  return (
                    <div key={step.id} className="flex flex-col items-center">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                          isCompleted
                            ? "bg-primary text-primary-foreground"
                            : isActive
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted text-muted-foreground"
                        }`}
                      >
                        <Icon className="h-4 w-4" />
                      </div>
                      <span className="text-xs text-center">{step.title}</span>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {React.createElement(steps[currentStep - 1].icon, { className: "h-5 w-5" })}
                {steps[currentStep - 1].title}
              </CardTitle>
              <CardDescription>
                {currentStep === 1 && "Enter your personal information"}
                {currentStep === 2 && "Provide your bank account details"}
                {currentStep === 3 && "Enter your student information"}
                {currentStep === 4 && "Review your information and submit"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Step 1: Personal Details */}
              {currentStep === 1 && (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="fullName">Full Name *</Label>
                    <Input
                      id="fullName"
                      value={formData.fullName}
                      onChange={(e) => updateFormData("fullName", e.target.value)}
                      placeholder="Enter your full name as per Aadhaar"
                      className={errors.fullName ? "border-destructive" : ""}
                    />
                    {errors.fullName && <p className="text-sm text-destructive mt-1">{errors.fullName}</p>}
                  </div>

                  <div>
                    <Label htmlFor="aadhaarNumber">Aadhaar Number *</Label>
                    <Input
                      id="aadhaarNumber"
                      value={formData.aadhaarNumber}
                      onChange={(e) => updateFormData("aadhaarNumber", formatAadhaar(e.target.value))}
                      placeholder="1234 5678 9012"
                      maxLength={14}
                      className={errors.aadhaarNumber ? "border-destructive" : ""}
                    />
                    {errors.aadhaarNumber && <p className="text-sm text-destructive mt-1">{errors.aadhaarNumber}</p>}
                  </div>

                  <div>
                    <Label htmlFor="mobileNumber">Mobile Number *</Label>
                    <Input
                      id="mobileNumber"
                      value={formData.mobileNumber}
                      onChange={(e) => updateFormData("mobileNumber", e.target.value.replace(/\D/g, ""))}
                      placeholder="9876543210"
                      maxLength={10}
                      className={errors.mobileNumber ? "border-destructive" : ""}
                    />
                    {errors.mobileNumber && <p className="text-sm text-destructive mt-1">{errors.mobileNumber}</p>}
                  </div>

                  <Alert>
                    <Shield className="h-4 w-4" />
                    <AlertDescription>
                      Your personal information is encrypted and secure. We follow all government data protection
                      guidelines.
                    </AlertDescription>
                  </Alert>
                </div>
              )}

              {/* Step 2: Bank Information */}
              {currentStep === 2 && (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="bankName">Bank Name *</Label>
                    <Select value={formData.bankName} onValueChange={(value) => updateFormData("bankName", value)}>
                      <SelectTrigger className={errors.bankName ? "border-destructive" : ""}>
                        <SelectValue placeholder="Select your bank" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sbi">State Bank of India</SelectItem>
                        <SelectItem value="hdfc">HDFC Bank</SelectItem>
                        <SelectItem value="icici">ICICI Bank</SelectItem>
                        <SelectItem value="axis">Axis Bank</SelectItem>
                        <SelectItem value="pnb">Punjab National Bank</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.bankName && <p className="text-sm text-destructive mt-1">{errors.bankName}</p>}
                  </div>

                  <div>
                    <Label htmlFor="bankAccount">Bank Account Number *</Label>
                    <Input
                      id="bankAccount"
                      value={formData.bankAccount}
                      onChange={(e) => updateFormData("bankAccount", e.target.value.replace(/\D/g, ""))}
                      placeholder="Enter your account number"
                      className={errors.bankAccount ? "border-destructive" : ""}
                    />
                    {errors.bankAccount && <p className="text-sm text-destructive mt-1">{errors.bankAccount}</p>}
                  </div>

                  <div>
                    <Label htmlFor="ifscCode">IFSC Code *</Label>
                    <Input
                      id="ifscCode"
                      value={formData.ifscCode}
                      onChange={(e) => updateFormData("ifscCode", e.target.value.toUpperCase())}
                      placeholder="SBIN0001234"
                      maxLength={11}
                      className={errors.ifscCode ? "border-destructive" : ""}
                    />
                    {errors.ifscCode && <p className="text-sm text-destructive mt-1">{errors.ifscCode}</p>}
                  </div>

                  <div>
                    <Label htmlFor="accountType">Account Type *</Label>
                    <Select
                      value={formData.accountType}
                      onValueChange={(value) => updateFormData("accountType", value)}
                    >
                      <SelectTrigger className={errors.accountType ? "border-destructive" : ""}>
                        <SelectValue placeholder="Select account type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="savings">Savings Account</SelectItem>
                        <SelectItem value="current">Current Account</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.accountType && <p className="text-sm text-destructive mt-1">{errors.accountType}</p>}
                  </div>
                </div>
              )}

              {/* Step 3: Student Details */}
              {currentStep === 3 && (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="studentId">Student ID *</Label>
                    <Input
                      id="studentId"
                      value={formData.studentId}
                      onChange={(e) => updateFormData("studentId", e.target.value)}
                      placeholder="Enter your student ID"
                      className={errors.studentId ? "border-destructive" : ""}
                    />
                    {errors.studentId && <p className="text-sm text-destructive mt-1">{errors.studentId}</p>}
                  </div>

                  <Alert>
                    <GraduationCap className="h-4 w-4" />
                    <AlertDescription>
                      Your student ID helps us track scholarship and benefit disbursements to your account.
                    </AlertDescription>
                  </Alert>
                </div>
              )}

              {/* Step 4: Review & Submit */}
              {currentStep === 4 && (
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold mb-3">Personal Information</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Full Name:</span>
                          <span>{formData.fullName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Aadhaar:</span>
                          <span>{formData.aadhaarNumber}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Mobile:</span>
                          <span>{formData.mobileNumber}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-3">Bank Information</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Bank:</span>
                          <span>{formData.bankName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Account:</span>
                          <span>{formData.bankAccount}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">IFSC:</span>
                          <span>{formData.ifscCode}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Type:</span>
                          <span>{formData.accountType}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-3">Student Information</h4>
                    <div className="text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Student ID:</span>
                        <span>{formData.studentId}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="consent"
                      checked={formData.consent}
                      onCheckedChange={(checked) => updateFormData("consent", checked as boolean)}
                    />
                    <Label htmlFor="consent" className="text-sm leading-relaxed">
                      I hereby consent to the seeding of my Aadhaar number with my bank account and agree to the terms
                      and conditions. I understand that this information will be used for government benefit transfers.
                    </Label>
                  </div>
                  {errors.consent && <p className="text-sm text-destructive">{errors.consent}</p>}
                </div>
              )}

              {/* Navigation Buttons */}
              <div className="flex justify-between pt-6">
                <Button variant="outline" onClick={prevStep} disabled={currentStep === 1} className="bg-transparent">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Previous
                </Button>

                {currentStep < 4 ? (
                  <Button onClick={nextStep}>
                    Next
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                ) : (
                  <Button onClick={handleSubmit} disabled={isSubmitting}>
                    {isSubmitting ? "Submitting..." : "Submit Form"}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
